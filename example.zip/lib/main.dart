import 'package:example/content_menu_example.dart';
import 'package:example/pan_example.dart';
import 'package:example/pinch_example.dart';
import 'package:example/rotate_example.dart';
import 'package:example/swipe_example.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(
    const MaterialApp(
      home: GestureExample(),
    ),
  );
}

class GestureExample extends StatefulWidget {
  const GestureExample({super.key});

  @override
  _GestureExampleState createState() => _GestureExampleState();
}

class _GestureExampleState extends State<GestureExample> {
  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: <Widget>[
        ElevatedButton(
          child: Text('滚动平移'),
          onPressed: () {
            // 跳转到第二个页面
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => PanExample()),
            );
          },
        ),
        SizedBox(
          height: 40,
        ),
        ElevatedButton(
          child: Text('缩放'),
          onPressed: () {
            // 跳转到第二个页面
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => PinchExample()),
            );
          },
        ),
        SizedBox(
          height: 40,
        ),
        ElevatedButton(
          child: Text('旋转'),
          onPressed: () {
            // 跳转到第二个页面
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => RotateExample()),
            );
          },
        ),
        SizedBox(
          height: 40,
        ),
        ElevatedButton(
          child: Text('轻扫'),
          onPressed: () {
            // 跳转到第二个页面
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => SwipeExample()),
            );
          },
        ),
        SizedBox(
          height: 40,
        ),
        ElevatedButton(
          child: Text('上下文菜单'),
          onPressed: () {
            // 跳转到第二个页面
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => ContentMenuExample()),
            );
          },
        ),
      ],
    );
  }
}
