import 'package:flutter/material.dart';
import 'package:hadss_unified_gesture_detector/hadss_unified_gesture_detector.dart';

class ContentMenuExample extends StatefulWidget {
  const ContentMenuExample({super.key});

  @override
  _ContentMenuExampleState createState() => _ContentMenuExampleState();
}

class _ContentMenuExampleState extends State<ContentMenuExample> {
  String lastEventName = 'Tap on screen';
  final panDirection = PanDirection.All.value;
  double _scale = 1.0;
  double _previousScale = 1.0;
  double _rotation = 0.0;
  double _previousRotation = 0.0;
  Offset _offset = Offset.zero;
  Offset _previousOffset = Offset.zero;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('上下文菜单'),
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
      ),
      body: UnifiedGestureDetector(
        pointerOptions: PointerOptions(),
        onContentMenu: onContentMenu,
        child: Material(
          child: Center(
            child: Transform(
              alignment: Alignment.center,
              transform: Matrix4.identity()
                ..translate(_offset.dx, _offset.dy)
                ..rotateZ(_rotation)
                ..scale(_scale),
              child: Container(
                width: 200,
                height: 200,
                color: Colors.green,
                alignment: Alignment.center,
                child: const Text(
                  '上下文菜单',
                  style: TextStyle(fontSize: 30),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  void onContentMenu(GestureEvent event) {
    setLastEventName('onContentMenu');
    print('onContentMenu');

    final RenderBox overlay =
    Overlay.of(context).context.findRenderObject() as RenderBox;
    showMenu(
        context: context,
        position: RelativeRect.fromRect(
            Rect.fromPoints(event.localPosition!, event.localPosition!),
            overlay.semanticBounds),
        items: [
          const PopupMenuItem<String>(value: 'copy', child: Text('复制')),
          const PopupMenuItem<String>(value: 'paste', child: Text('粘贴')),
          const PopupMenuItem<String>(value: 'delete', child: Text('删除'))
        ]).then((value) {
      if (value != null) {
        // 处理选择
        print('选择了：${value}');
      }
    });
  }

  void setLastEventName(String eventName) {
    setState(() {
      lastEventName = eventName;
    });
  }
}
