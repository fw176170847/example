import 'package:flutter/material.dart';
import 'package:hadss_unified_gesture_detector/hadss_unified_gesture_detector.dart';

class PanExample extends StatefulWidget {
  const PanExample({super.key});

  @override
  _PanExampleState createState() => _PanExampleState();
}

class _PanExampleState extends State<PanExample> {
  String lastEventName = 'Tap on screen';
  final panDirection = PanDirection.All.value;
  double _scale = 1.0;
  double _previousScale = 1.0;
  double _rotation = 0.0;
  double _previousRotation = 0.0;
  Offset _offset = Offset.zero;
  Offset _previousOffset = Offset.zero;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('滚动平移'),
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
      ),
      body: UnifiedGestureDetector(
        pointerOptions: PointerOptions(
            enablePan: true,
            panDirection: panDirection),
        onPanStart: onPanStart,
        onPanUpdate: onPanUpdate,
        onPanEnd: onPanEnd,
        child: Material(
          child: Center(
            child: Transform(
              alignment: Alignment.center,
              transform: Matrix4.identity()
                ..translate(_offset.dx, _offset.dy)
                ..rotateZ(_rotation)
                ..scale(_scale),
              child: Container(
                width: 200,
                height: 200,
                color: Colors.green,
                alignment: Alignment.center,
                child: const Text(
                  '滚动平移',
                  style: TextStyle(fontSize: 30),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  void onPanStart(GestureEvent event) {
    setLastEventName('onPanStart');
  }

  void onPanUpdate(GestureEvent event) {
    setLastEventName('onPanUpdate');
    print('${event.offsetX!}    ${event.offsetY!}');
    _offset = Offset(event.offsetX!, event.offsetY!);
  }

  void onPanEnd(GestureEvent event) {
    setLastEventName('onPanEnd');
  }

  void setLastEventName(String eventName) {
    setState(() {
      lastEventName = eventName;
    });
  }
}
