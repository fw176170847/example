import 'package:flutter/material.dart';
import 'package:hadss_unified_gesture_detector/hadss_unified_gesture_detector.dart';

class PinchExample extends StatefulWidget {
  const PinchExample({super.key});

  @override
  _PinchExampleState createState() => _PinchExampleState();
}

class _PinchExampleState extends State<PinchExample> {
  String lastEventName = 'Tap on screen';
  final panDirection = PanDirection.All.value;
  double _scale = 1.0;
  double _previousScale = 1.0;
  double _rotation = 0.0;
  double _previousRotation = 0.0;
  Offset _offset = Offset.zero;
  Offset _previousOffset = Offset.zero;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('缩放'),
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
      ),
      body: UnifiedGestureDetector(
        pointerOptions: PointerOptions(
            enablePinch: true,),
        onPinchStart: onPinchStart,
        onPinchUpdate: onPinchUpdate,
        onPinchEnd: onPinchEnd,
        child: Material(
          child: Center(
            child: Transform(
              alignment: Alignment.center,
              transform: Matrix4.identity()
                ..translate(_offset.dx, _offset.dy)
                ..rotateZ(_rotation)
                ..scale(_scale),
              child: Container(
                width: 200,
                height: 200,
                color: Colors.green,
                alignment: Alignment.center,
                child: const Text(
                  '缩放',
                  style: TextStyle(fontSize: 30),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  void onPinchStart(GestureEvent event) {
    setLastEventName('onPinchStart');
  }

  void onPinchUpdate(GestureEvent event) {
    setLastEventName('onPinchUpdate');

    // 根据滚轮方向调整缩放比例
    if (event.scale! < 0) {
      _scale -= 0.1; // 向上滚，缩小
    } else if (event.scale! > 0) {
      _scale += 0.1; // 向下滚，放大
    }

    // 限制缩放范围
    _scale = _scale.clamp(0.5, 3.0);
  }

  void onPinchEnd(GestureEvent event) {
    setLastEventName('onPinchEnd');
    print('onPinchEnd');
  }

  void setLastEventName(String eventName) {
    setState(() {
      lastEventName = eventName;
    });
  }
}
