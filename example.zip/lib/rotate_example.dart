import 'package:flutter/material.dart';
import 'package:hadss_unified_gesture_detector/hadss_unified_gesture_detector.dart';

class RotateExample extends StatefulWidget {
  const RotateExample({super.key});

  @override
  _RotateExampleState createState() => _RotateExampleState();
}

class _RotateExampleState extends State<RotateExample> {
  String lastEventName = 'Tap on screen';
  final panDirection = PanDirection.All.value;
  double _scale = 1.0;
  double _previousScale = 1.0;
  double _rotation = 0.0;
  double _previousRotation = 0.0;
  Offset _offset = Offset.zero;
  Offset _previousOffset = Offset.zero;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('旋转'),
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
      ),
      body: UnifiedGestureDetector(
        pointerOptions: PointerOptions(
            enableRotate: true,),
        onRotateStart: onRotateStart,
        onRotateUpdate: onRotateUpdate,
        onRotateEnd: onRotateEnd,
        child: Material(
          child: Center(
            child: Transform(
              alignment: Alignment.center,
              transform: Matrix4.identity()
                ..translate(_offset.dx, _offset.dy)
                ..rotateZ(_rotation)
                ..scale(_scale),
              child: Container(
                width: 200,
                height: 200,
                color: Colors.green,
                alignment: Alignment.center,
                child: const Text(
                  '旋转',
                  style: TextStyle(fontSize: 30),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  void onRotateStart(GestureEvent event) {
    setLastEventName('onRotateStart');
    print('onRotateStart');
  }

  void onRotateUpdate(GestureEvent event) {
    setLastEventName('onRotateUpdate');
    print('onRotateUpdate');

    _rotation = event.angle!;
  }

  void onRotateEnd(GestureEvent event) {
    setLastEventName('onRotateEnd');
    print('onRotateEnd');
  }

  void setLastEventName(String eventName) {
    setState(() {
      lastEventName = eventName;
    });
  }
}
