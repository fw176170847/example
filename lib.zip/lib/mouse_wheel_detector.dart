import 'package:flutter/cupertino.dart';
import 'package:flutter/services.dart';

class MouseWheelDetector extends StatefulWidget {
  MouseWheelDetector({
    required this.child,
    required this.onControlPress,
    required this.onShiftPress,
  });

  final Widget child;

  final Function(bool isPressed)? onControlPress;
  final Function(bool isPressed)? onShiftPress;

  @override
  MouseWheelDetectorState createState() {
    return MouseWheelDetectorState();
  }
}

class MouseWheelDetectorState extends State<MouseWheelDetector> {
  @override
  Widget build(BuildContext context) {
    return RawKeyboardListener(
      focusNode: FocusNode(),
      autofocus: true,
      onKey: (RawKeyEvent event) {
        if (event is RawKeyDownEvent) {
          if (event.logicalKey == LogicalKeyboardKey.controlLeft ||
              event.logicalKey == LogicalKeyboardKey.controlRight) {
            widget.onControlPress!(true);
          } else if (event.logicalKey == LogicalKeyboardKey.shiftLeft ||
              event.logicalKey == LogicalKeyboardKey.shiftRight) {
            widget.onShiftPress!(true);
          }
        } else if (event is RawKeyUpEvent) {
          if (event.logicalKey == LogicalKeyboardKey.controlLeft ||
              event.logicalKey == LogicalKeyboardKey.controlRight) {
            widget.onControlPress!(false);
          } else if (event.logicalKey == LogicalKeyboardKey.shiftLeft ||
              event.logicalKey == LogicalKeyboardKey.shiftRight) {
            widget.onShiftPress!(false);
          }
        }
      },
      child: widget.child,
    );
  }
}
