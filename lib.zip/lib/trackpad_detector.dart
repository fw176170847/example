import 'dart:ui';

import 'package:flutter/cupertino.dart';

class TrackpadDetector extends StatefulWidget {
  TrackpadDetector({
    required this.child,
    required this.onScaleStart,
    required this.onScaleUpdate,
    required this.onScaleEnd,
  });

  final Widget? child;
  final Function()? onScaleStart;
  final Function(Offset startOffset, Offset updateOffset, double scale)?
      onScaleUpdate;
  final Function(Offset startOffset, Offset updateOffset, DateTime startTime)?
      onScaleEnd;

  @override
  TrackpadDetectorState createState() {
    return TrackpadDetectorState();
  }
}

class TrackpadDetectorState extends State<TrackpadDetector> {
  PointerDeviceKind _kind = PointerDeviceKind.unknown;
  int _pointCount = 0; // 区分触控板的手指数量
  // 针对触控板
  Offset _startOffset = const Offset(0, 0);
  Offset _updateOffset = const Offset(0, 0);
  DateTime _startTime = DateTime.now();

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (detail) {
        _kind = detail.kind!;
        print('$_kind');
      },
      onTapUp: (details) {
        // tapCancel不要随便加，触发很扯淡
        _kind = PointerDeviceKind.unknown;

        print(_kind);
      },
      onScaleStart: (detail) {

        _pointCount = detail.pointerCount;
        if (_kind != PointerDeviceKind.touch) {
          // 触摸板
          print('$_kind $detail');
          _startOffset = detail.localFocalPoint;
          _startTime = DateTime.now();
          if (widget.onScaleStart != null) {
            widget.onScaleStart!();
          }
        }
      },
      onScaleUpdate: (detail) {
        // print(_kind);

        _pointCount = detail.pointerCount;
        if (_kind != PointerDeviceKind.touch) {
          // 触摸板
          print('$_kind $detail');
          // print('323232');
          _updateOffset = detail.localFocalPoint;
          if (widget.onScaleUpdate != null) {
            widget.onScaleUpdate!(_startOffset, _updateOffset, detail.scale);
          }
        }
      },
      onScaleEnd: (detail) {
        if (_kind != PointerDeviceKind.touch) {
          // 触摸板
          if (widget.onScaleEnd != null) {
            widget.onScaleEnd!(_startOffset, _updateOffset, _startTime);
          }

          _pointCount = 0;
        }
      },
      child: widget.child,
    );
  }
}