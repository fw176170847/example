/*
 * Copyright (c) 2025 Huawei Device Co., Ltd.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import 'dart:ui';

/// 事件返回对象
class GestureEvent {
  /// 是否为重复触发事件，用于LongPressGesture手势触发场景。
  bool? repeat;

  /// 手势事件偏移量X，单位为vp，用于PanGesture手势触发场景，从左向右滑动offsetX为正，反之为负。
  double? offsetX;

  /// 手势事件偏移量Y，单位为vp，用于PanGesture手势触发场景，从上向下滑动offsetY为正，反之为负。
  double? offsetY;

  /// 用于RotationGesture手势触发场景时，表示旋转角度。
  /// 用于SwipeGesture手势触发场景时，表示滑动手势的角度，即两根手指间的线段与水平方向的夹角变化的度数。
  /// 说明：角度计算方式：滑动手势被识别到后，连接两根手指之间的线被识别为起始线条，随着手指的滑动，手指之间的线条会发生旋转，
  /// 根据起始线条两端点和当前线条两端点的坐标，使用反正切函数分别计算其相对于水平方向的夹角，
  /// 最后arctan2(cy2-cy1,cx2-cx1)-arctan2(y2-y1,x2-x1)为旋转的角度。以起始线条为坐标系，顺时针旋转为0到180度，逆时针旋转为-180到0度。
  double? angle;

  /// 缩放比例，用于PinchGesture手势触发场景。取值范围：[0, +∞)
  double? scale;

  /// 捏合手势中心点的x轴坐标，单位为vp，用于PinchGesture手势触发场景。
  /// 取值范围：[0, +∞)
  double? pinchCenterX;

  /// 捏合手势中心点的y轴坐标，单位为vp，用于PinchGesture手势触发场景。
  /// 取值范围：[0, +∞)
  double? pinchCenterY;

  /// 滑动手势速度，即所有手指相对当前组件元素原始区域滑动的平均速度，单位为dp/秒，用于SwipeGesture手势触发场景。
  /// 取值范围：[0, +∞)
  double? speed;

  /// 用于PanGesture手势中，获取当前手势的x轴方向速度。坐标轴原点为屏幕左上角，分正负方向速度，从左往右为正，反之为负。单位为dp/s。
  double? velocityX;

  /// 用于PanGesture手势中，获取当前手势的y轴方向速度。坐标轴原点为屏幕左上角，分正负方向速度，从上往下为正，反之为负。单位为dp/s。
  double? velocityY;

  /// 用于PanGesture手势中，获取当前手势的主方向速度。为xy轴方向速度的平方和的算术平方根。单位为dp/s。
  double? velocity;

  /// 提供给上下文菜单显示使用，表明当前鼠标或者触控点的位置
  Offset? localPosition;

  /// 构造函数
  GestureEvent({
    this.repeat,
    this.offsetX,
    this.offsetY,
    this.angle,
    this.scale,
    this.pinchCenterX,
    this.pinchCenterY,
    this.speed,
    this.velocityX,
    this.velocityY,
    this.velocity,
    this.localPosition,
  });
}
