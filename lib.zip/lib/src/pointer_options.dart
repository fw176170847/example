/*
 * Copyright (c) 2025 Huawei Device Co., Ltd.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/// 手势识别配置选项
class PointerOptions {
  /// 触发滑动手势的滑动方向。 默认值：SwipeDirection.All
  final SwipeDirection direction;

  /// 识别滑动的最小速度。 默认值：100dp/s
  /// 说明：当滑动速度的值小于等于0时，会被转化为默认值。
  final double speed;

  /// 轻扫功能开关
  final bool enableSwipe;

  /// 用于指定触发滑动的手势方向，此枚举值支持逻辑与(&)和逻辑或（|）运算。
  final int panDirection;

  /// 用于指定触发滑动手势事件的最小滑动距离，单位为vp。取值范围：[0, +∞) 默认值：5
  /// 说明：当设定的值小于0时，按默认值5处理。
  final double distance;

  /// 滚动功能开关
  final bool enablePan;

  /// 最小识别距离，单位为dp。 默认值：5
  /// 说明：取值范围：(0, +∞)，当识别距离的值小于等于0时，会被转化为默认值。
  final double pinchDistance;

  /// 缩放功能开关
  final bool enablePinch;

  /// 触发旋转手势的最小改变度数，单位为deg。默认值：1
  /// 说明： 当改变度数的值小于等于0或大于360时，会被转化为默认值。
  final double angle;

  /// 旋转功能开关
  final bool enableRotate;

  /// 默认构造函数
  const PointerOptions({
    this.direction = SwipeDirection.All,
    this.speed = 100.0,
    this.enableSwipe = false,
    this.panDirection = 0xFF,
    this.distance = 5.0,
    this.enablePan = false,
    this.pinchDistance = 5.0,
    this.enablePinch = false,
    this.angle = 1,
    this.enableRotate = false,
  });

  // 检查权限组合
  bool hasPanDirection(int directionValue, PanDirection rightDirection) {
    bool result =
        (directionValue & rightDirection.value) == rightDirection.value;
    return result;
  }
}

/// 轻扫方向枚举
enum SwipeDirection {
  All, // 所有方向
  Horizontal, // 水平方向（与x轴夹角<45°）
  Vertical, // 垂直方向（与y轴夹角<45°）
  None, // 不触发
}

/// 滚动方向枚举（支持位运算组合）
enum PanDirection {
  All(0xFF), // 所有方向
  Horizontal(0x03), // 水平方向
  Vertical(0x0C), // 垂直方向
  Left(0x01), // 向左
  Right(0x02), // 向右
  Up(0x04), // 向上
  Down(0x08), // 向下
  None(0x00); // 不触发

  const PanDirection(this.value);

  final int value;

  int operator |(int other) {
    return value | other;
  }

  /// 逻辑与，交集方向
  int operator &(int other) {
    if (value == All.value) {
      return other;
    } else if (other == All.value) {
      return value;
    } else if (value == Horizontal.value &&
        (other == Left.value || other == Right.value)) {
      return other;
    } else if (other == Horizontal.value &&
        (value == Left.value || value == Right.value)) {
      return value;
    } else if (value == Vertical.value &&
        (other == Up.value || other == Down.value)) {
      return other;
    } else if (other == Vertical.value &&
        (value == Up.value || value == Down.value)) {
      return value;
    } else {
      return None.value;
    }
  }
}
